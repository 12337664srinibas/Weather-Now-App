import { useState, useEffect } from 'react'
import './App.css'

function App() {
  const [city, setCity] = useState('')
  const [weather, setWeather] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  // Function to get coordinates for a city
  const getCoordinates = async (cityName) => {
    try {
      console.log('Searching for coordinates of:', cityName)
      const response = await fetch(
        `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(cityName)}&count=1&language=en&format=json`
      )

      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`)

      const data = await response.json()
      console.log('Geocoding response:', data)

      if (data.results && data.results.length > 0) {
        return {
          lat: data.results[0].latitude,
          lon: data.results[0].longitude,
          name: data.results[0].name,
          country: data.results[0].country
        }
      }
      throw new Error('City not found')
    } catch (err) {
      console.error('Geocoding error:', err)
      throw new Error('Unable to find city coordinates')
    }
  }

  // Function to get weather data
  const getWeatherData = async (lat, lon) => {
    try {
      const response = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&hourly=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,rain,showers,snowfall,weather_code,cloud_cover,pressure_msl,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m&timezone=auto`
      )

      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`)

      const data = await response.json()
      console.log('Weather response:', data)
      return data
    } catch (err) {
      console.error('Weather API error:', err)
      throw new Error('Unable to fetch weather data')
    }
  }

  // Weather code → description
  const getWeatherDescription = (code) => {
    const weatherCodes = {
      0: 'Clear sky',
      1: 'Mainly clear',
      2: 'Partly cloudy',
      3: 'Overcast',
      45: 'Fog',
      48: 'Depositing rime fog',
      51: 'Light drizzle',
      53: 'Moderate drizzle',
      55: 'Dense drizzle',
      56: 'Light freezing drizzle',
      57: 'Dense freezing drizzle',
      61: 'Slight rain',
      63: 'Moderate rain',
      65: 'Heavy rain',
      66: 'Light freezing rain',
      67: 'Heavy freezing rain',
      71: 'Slight snow fall',
      73: 'Moderate snow fall',
      75: 'Heavy snow fall',
      77: 'Snow grains',
      80: 'Slight rain showers',
      81: 'Moderate rain showers',
      82: 'Violent rain showers',
      85: 'Slight snow showers',
      86: 'Heavy snow showers',
      95: 'Thunderstorm',
      96: 'Thunderstorm with slight hail',
      99: 'Thunderstorm with heavy hail'
    }
    return weatherCodes[code] || 'Unknown'
  }

  // Weather icon based on code
  const getWeatherIcon = (code, isDay) => {
    if (code === 0) return isDay ? '☀️' : '🌙'
    if (code <= 3) return isDay ? '⛅' : '🌙'
    if (code <= 48) return '🌫️'
    if (code <= 57) return '🌦️'
    if (code <= 67) return '🌧️'
    if (code <= 77) return '❄️'
    if (code <= 82) return '🌦️'
    if (code <= 86) return '🌨️'
    if (code >= 95) return '⛈️'
    return '🌤️'
  }

  const handleSearch = async (e) => {
    e.preventDefault()
    if (!city.trim()) {
      setError('Please enter a city name')
      return
    }

    setLoading(true)
    setError('')
    setWeather(null)

    try {
      const coordinates = await getCoordinates(city.trim())
      const weatherData = await getWeatherData(coordinates.lat, coordinates.lon)
      setWeather({
        ...weatherData,
        cityName: coordinates.name,
        country: coordinates.country
      })
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  // Load default city on startup
  useEffect(() => {
    const loadDefaultWeather = async () => {
      setLoading(true)
      try {
        const coordinates = await getCoordinates('Mumbai')
        const weatherData = await getWeatherData(coordinates.lat, coordinates.lon)
        setWeather({
          ...weatherData,
          cityName: coordinates.name,
          country: coordinates.country
        })
      } catch (err) {
        setError('Failed to load default weather data')
      } finally {
        setLoading(false)
      }
    }
    loadDefaultWeather()
  }, [])

  return (
    <div className="app">
      <div className="container">
        <header className="header">
          <h1>🌤️ Weather Now</h1>
          <p>Quick weather check for outdoor enthusiasts</p>
        </header>

        <form onSubmit={handleSearch} className="search-form">
          <div className="search-container">
            <input
              type="text"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="Enter city name..."
              className="search-input"
              disabled={loading}
            />
            <button type="submit" className="search-button" disabled={loading}>
              {loading ? '⏳' : '🔍'}
            </button>
          </div>
        </form>

        {error && <div className="error-message">⚠️ {error}</div>}

        {weather && weather.current_weather && (
          <div className="weather-card">
            <div className="weather-header">
              <h2>{weather.cityName}, {weather.country}</h2>
              <div className="weather-icon">
                {getWeatherIcon(weather.current_weather.weathercode, weather.current_weather.is_day)}
              </div>
            </div>

            <div className="weather-main">
              <div className="temperature">
                <span className="temp-value">{Math.round(weather.current_weather.temperature)}°</span>
                <span className="temp-unit">C</span>
              </div>
              <div className="weather-description">
                {getWeatherDescription(weather.current_weather.weathercode)}
              </div>
              <div className="feels-like">
                Feels like {Math.round(weather.current_weather.temperature)}°C
              </div>
            </div>

            <div className="weather-details">
              <div className="detail-grid">
                <div className="detail-item">
                  <span className="detail-label">💧 Humidity</span>
                  <span className="detail-value">{weather.hourly ? weather.hourly.relative_humidity_2m[0] : 'N/A'}%</span>
                </div>
                <div className="detail-item">
                  <span className="detail-label">💨 Wind Speed</span>
                  <span className="detail-value">{weather.current_weather.windspeed} km/h</span>
                </div>
                <div className="detail-item">
                  <span className="detail-label">🌫️ Cloud Cover</span>
                  <span className="detail-value">{weather.hourly ? weather.hourly.cloud_cover[0] : 'N/A'}%</span>
                </div>
                <div className="detail-item">
                  <span className="detail-label">🌡️ Pressure</span>
                  <span className="detail-value">{weather.hourly ? weather.hourly.pressure_msl[0] : 'N/A'} hPa</span>
                </div>
              </div>
            </div>

            <div className="last-updated">
              Last updated: {new Date(weather.current_weather.time).toLocaleTimeString()}
            </div>
          </div>
        )}

        <footer className="footer">
          <p>Perfect for planning your outdoor adventures! 🏔️</p>
          <small>Powered by Open-Meteo API</small>
        </footer>
      </div>
    </div>
  )
}

export default App
